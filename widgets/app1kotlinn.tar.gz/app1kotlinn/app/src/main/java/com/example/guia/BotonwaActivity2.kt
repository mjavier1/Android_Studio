package com.example.guia

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class BotonwaActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_botonwa2)
    }

    fun mostrabotonselecion(widget: View) {

var tag = widget.tag
        var mensaje = ""
        when(tag) {
            "Saludar"->{
        mensaje ="Presionate el boton normal"

            }
            "email"->
            {
                mensaje = "Presionaste el image button"
            }
        }
        Toast.makeText(applicationContext,mensaje,Toast.LENGTH_LONG).show()
    }
}