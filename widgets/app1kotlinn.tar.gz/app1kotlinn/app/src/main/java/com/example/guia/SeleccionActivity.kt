package com.example.guia

import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SeleccionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seleccion)
    }

    fun validar(view: View) {
        if(view is CheckBox) {
            if (view.isChecked) {
                Toast.makeText(applicationContext,"Check Seleccionado", Toast.LENGTH_SHORT).show()

            } else {
                Toast.makeText(applicationContext,"Check no Seleccionado", Toast.LENGTH_SHORT).show()
            }
        }
        else if (view is Switch)
        {
            if (view.isChecked){
                Toast.makeText(applicationContext,"switch Check Seleccionado", Toast.LENGTH_SHORT).show()
        }
            else{
            Toast.makeText(applicationContext,"seitch no Check Seleccionado", Toast.LENGTH_SHORT).show()
          }
        }
        else if (view is RadioButton){
            when(view.id){
                R.id.rad1 ->{
                    Toast.makeText(applicationContext,"selecionaste radio uno ", Toast.LENGTH_SHORT).show()
                }
                R.id.rad2 ->{
                    Toast.makeText(applicationContext,"selecionaste radio dps ", Toast.LENGTH_SHORT).show()
                }

            }
        }

    }

}