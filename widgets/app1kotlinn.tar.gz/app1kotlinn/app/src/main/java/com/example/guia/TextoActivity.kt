package com.example.guia

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_texto.*

class TextoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_texto)
        btndatos.setOnClickListener{
            var nombre : String = txtnombre.text.toString()
            var edad:String = txtedad.text.toString()

Toast.makeText (applicationContext,"Hola $nombre tienes$edad anos",Toast.LENGTH_LONG).show()

        }
    }
}