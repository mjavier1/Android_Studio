package com.example.guia

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_registro.*

var sexo = "Hombre"
class registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }


    fun registrar(view: View) {
        var correo = txtcorreo.text.toString()
        var pass = txtpass.text.toString()
        if (radhom.isChecked){
            sexo = "Hombre"
        }
        else
        {
            sexo = "Mujer"
        }
        var mensaje = "Correo:$correo\npass $pass\nsexo: $sexo"
        Toast.makeText(applicationContext,mensaje, Toast.LENGTH_SHORT).show()
    }
}