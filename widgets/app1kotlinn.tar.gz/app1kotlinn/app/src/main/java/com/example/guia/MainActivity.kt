package com.example.guia

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        btnTexto.setOnClickListener{
          var intent = Intent(applicationContext,TextoActivity::class.java)
        startActivity(intent)



        }

        btnbotones.setOnClickListener{
            var intent = Intent(applicationContext,BotonwaActivity2::class.java)
            startActivity(intent)
        }
        btnsele.setOnClickListener{
            var intent = Intent(applicationContext,SeleccionActivity::class.java)
            startActivity(intent)

        }
        btnre.setOnClickListener{
            var intent = Intent(applicationContext,registro::class.java)
            startActivity(intent)

        }

    }
}
