package com.example.sqt;

public class Name {
    private int id;
    private String name;
    private String namelast;

    public Name(){
        super();


    }
    public Name(int id,String name,String namelast){
        this.id=id;
        this.name=  name;
        this.namelast=namelast;

    }
    public Name (String name,String namelast){
        this.name=name;
        this.namelast=namelast;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamelast() {
        return namelast;
    }

    public void setNamelast(String namelast) {
        this.namelast = namelast;
    }
}
