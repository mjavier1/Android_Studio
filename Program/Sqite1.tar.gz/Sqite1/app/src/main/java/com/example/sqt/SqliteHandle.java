package com.example.sqt;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class SqliteHandle extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NAME="dbname.sql";

    private static  final String  TABLE_NAME="tablename";

    private static final String COMLUNM_ID="id";
    private static final  String COlUNM_NAME="name";
    private static final String COlUNM_lastNAME="lastname";

    String CREATE_NAME_TABLE="CREATE TABLE "+TABLE_NAME + "("
            +COMLUNM_ID+"INTERGER PRIMARY KEY ," + COlUNM_NAME + "TEXT ,"
            + COlUNM_lastNAME + "TEXT  " + ")";

    public SqliteHandle (Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);

    }
public void onCreate(SQLiteDatabase db) {
    db.execSQL(CREATE_NAME_TABLE);
}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldv, int newv) {
db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME );
onCreate(db);
    }
public void addname(Name name ){
SQLiteDatabase database = this.getWritableDatabase();
ContentValues contextvalue = new ContentValues();
    contextvalue.put(COlUNM_NAME,name.getName());
    contextvalue.put(COlUNM_lastNAME,name.getNamelast());
    database.insert(TABLE_NAME,null,contextvalue);
    database.close();//getting single
    }
public Name getName(int id){
    SQLiteDatabase database = this.getReadableDatabase();
    Cursor cursor=database.query(TABLE_NAME, new String[]{COMLUNM_ID,COlUNM_NAME,COlUNM_lastNAME},
            COMLUNM_ID+"=?" ,new String[]{String.valueOf(id)},null,null,null );
    if(cursor!=null){
       cursor.moveToFirst();
    }
    Name name= new Name(Integer.parseInt(cursor.getString(0)),cursor.getString(1)
    ,cursor.getString(2));
    return name;
}
//get all computer obj
  public List<Name> getAllName(){
List<Name> names= new ArrayList<>();
String SELECT_ALL_QUERY="SELECT * FROM TABLE_NAME";
SQLiteDatabase database=this.getReadableDatabase();
Cursor cursor= database.rawQuery(SELECT_ALL_QUERY,null);
if (cursor.moveToFirst()){
    do {
        Name name= new Name();
        name.setId(Integer.parseInt(cursor.getString(0)));
        name.setName(cursor.getString(1));
        name.setNamelast(cursor.getString(2));
        names.add(name);



    }
    while(cursor.moveToNext());
}
return names;

  }
//update
  public int updatename(Name name){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COlUNM_NAME,name.getName());
        contentValues.put(COlUNM_lastNAME,name.getNamelast());

        return database.update(TABLE_NAME,contentValues,COMLUNM_ID+"=?",
                new String[]{
                      String.valueOf(name.getId())
                });
  }
  //delete
    public void deletename(Name name){
        SQLiteDatabase database=this.getWritableDatabase();
        database.delete(TABLE_NAME,COMLUNM_ID+"=?",new String[]{
            String.valueOf(name.getId())});
      database.close();
    }
//getting numbers of name
    public int getNameCount(){
        String Name_COUNT_QUERY="SELECT * FROM " +TABLE_NAME;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(Name_COUNT_QUERY,null);
return cursor.getCount();
    }

}
