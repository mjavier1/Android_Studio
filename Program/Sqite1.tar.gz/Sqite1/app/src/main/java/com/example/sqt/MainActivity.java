package com.example.sqt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editname, editlst;
    Button btnadd, btndelete;
    ListView listview;
    List<Name> allname;
    ArrayList<String> COlUNM_NAME;
    SqliteHandle databaseHandler;
    ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editname = findViewById(R.id.editname);

        editlst = findViewById(R.id.editlst);
        btnadd = findViewById(R.id.btnAdd);
        btndelete = findViewById(R.id.btndelete);
        listview = findViewById(R.id.listview);
        databaseHandler = new SqliteHandle(MainActivity.this);
        allname = databaseHandler.getAllName();
        COlUNM_NAME = new ArrayList<>();
        if (allname.size() > 0){
            for (int i = 0; i < allname.size(); i++) {
                Name name = allname.get(i);
                COlUNM_NAME.add(name.getName() + "-" + " " + name.getNamelast());

            }
    }

    adapter= new ArrayAdapter(this, android.R.layout.simple_list_item_1,COlUNM_NAME);
    listview.setAdapter(adapter);
    btnadd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(editname.getText().toString().matches("") || editlst.getText().toString().matches("") ){
          return ;

        }
            Name name = new Name(editname.getText().toString(),editlst.getText().toString());
            allname.add(name);
            databaseHandler.addname(name);
            COlUNM_NAME.add(name.getName()+"-"+name.getNamelast());
            editname.setText("");
            editlst.setText("");
            adapter.notifyDataSetChanged();

        }
    });
btndelete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(allname.size()>0){
            COlUNM_NAME.remove(0);
            databaseHandler.deletename(allname.get(0));
           allname.remove(0);
           adapter.notifyDataSetChanged();

        }
else   {
    return;
        }

    }
});

}
}